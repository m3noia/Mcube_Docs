#include "CentralServerService.h"

CentralServerService::CentralServerService()
{

}
