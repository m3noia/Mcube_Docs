#include "CentralServer.h"

CentralServer::CentralServer()
{

}
